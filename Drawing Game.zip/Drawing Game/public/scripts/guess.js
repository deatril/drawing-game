// Init guess
function initGuess(){
  // Receive drawing for server
  socket.on('dessin', function(c) {
    clearInterval(interval);
    $('#palette').hide();
    $('#canvas').hide();
    $('#drawing_validate').hide();
    $('#draw').show();

    var img = new Image();
    img.src = c;
    $('#draw').append(img);
  });
}
