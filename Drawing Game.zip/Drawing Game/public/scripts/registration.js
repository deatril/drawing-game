//Init registration
function initRegistration(){
  //hide/show
  $('#lobby').hide();
  $('#top_part').hide();
  $('#middle_part').hide();
  $('#bottom_part').hide();

  $('#registration').on('submit', function(e){
    socket.emit('new_player', {gameId: gameId, pseudo: $('#inputPseudo').val(), topic: $('#inputTopic').val()});
    document.title = $('#inputPseudo').val();
    return false;
  });

  //Display lobby screen
  socket.on('lobby', function() {
    initLobby();
  });
}
