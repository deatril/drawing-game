var canvas, ctx, interval, socket,
  flag = false;
  prevX = 0,
  prevY = 0,
  currX = 0,
  currY = 0,
  canvasW = 0,
  canvasH = 0,
  timer = 15;

var gameId = window.location.href.split('/')[window.location.href.split('/').length-1];

window.onload = function(e) {
  socket = io.connect('http://localhost:8080');

  //error message
  socket.on('message', function(m){
    alert(m);
  });

  initRegistration();
};
