// Init lobby
function initLobby(){
  //hide show
  $('#lobby').show();
  $('#registration').hide();
  $('#top_part').hide();
  $('#middle_part').hide();
  $('#bottom_part').hide();
  $('#player_not_ready').hide();

  //btn event
  $('#player_ready').on('click', function(e){
    $('#player_not_ready').show();
    $('#player_ready').hide();
    playerReady(true);
  });
  $('#player_not_ready').on('click', function(e){
    $('#player_ready').show();
    $('#player_not_ready').hide();
    playerReady(false);
  });

  socket.on('players_list', function(p) {
    displayPlayerNumber(p);
    displayPlayersList(p);
  });

  socket.on('start', function() {
    initDraw();
  });
}

//Display players list
function displayPlayersList(players){
  var htmlString = '';
  htmlString += '<ul class="list-group">';
  for(var i = 0; i < players.length; i++){
    htmlString += '<li class="list-group-item">';
    htmlString += players[i].pseudo;
    htmlString += (players[i].ready) ? ' ready' : '';
    htmlString += '</li>';
  }
  htmlString += '</ul>';
  $('#players_list').empty();
  $('#players_list').append(htmlString);
}

//display number of player ready
function displayPlayerNumber(players) {
  var nbReady = 0;
  for(var i = 0; i < players.length; i++){
    if(players[i].ready){
      nbReady++;
    }
  }

  var htmlString = '';
  htmlString += nbReady + '/' + players.length;
  $('#number_player').empty();
  $('#number_player').append(htmlString);
}

//Player ready/nor ready
function playerReady(r) {
  socket.emit('player_ready',r);
}
