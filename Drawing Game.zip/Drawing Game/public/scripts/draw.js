// Init draw
function  initDraw() {

  canvas = $('#canvas');
  ctx = canvas[0].getContext("2d");

  canvas[0].width = window.innerWidth/2;
  canvas[0].height = window.innerHeight/2;

  displayDrawScreen();

  canvas.on('mousemove', function(e){
    findXY("move", e);
  });
  canvas.on('mousedown', function(e){
    findXY("down", e);
  });
  canvas.on('mouseup', function(e){
    findXY("up", e);
  });
  canvas.on('mouseout', function(e){
    findXY("out", e);
  });

  //Timer management
  $('#timer').append(timer);
  interval = setInterval(function(){
    if(timer == 0) {
      $('#timer').removeClass('blink');
      $('#timer').css('color', 'red');
      clearInterval(interval);
      sendDessin();
    } else {
      timer--;
      $('#timer').empty();
      $('#timer').append(timer);
      if(timer < 10) {
        $('#timer').addClass('blink');
      }
    }
  }, 1000);

  $('#drawing_validate').on('click', function(e){
    $('#drawing_validate').prop('disabled', true);
    clearInterval(interval);
    sendDessin();
  });

  $('#guessing_validate').on('click', function(e){
    $('#guessing_validate').prop('disabled', true);
    $('#inputGuess').prop('disabled', true);
    clearInterval(interval);
    sendGuess();
  });

  socket.on('draw', function(topic){
    displayDrawScreen();
    $('#title').empty();
    $('#title').append(topic);
  });

  socket.on('guess', function(image){

    displayGuessScreen();
    var img = new Image();
    img.src = image;
    $('#draw').empty();
    $('#draw').append(img);
  });
}


//display draw screen
function displayDrawScreen(){
  $('#registration').hide();
  $('#lobby').hide();
  $('#draw').hide();
  $('#draw').empty();
  $('#bottom_part_guess').hide();

  ctx.clearRect(0, 0, canvas[0].width, canvas[0].height);
  $('#drawing_validate').prop('disabled', false);

  $('#top_part').show();
  $('#middle_part').show();
  $('#draw_panel').show();
  $('#bottom_part').show();
  $('#drawing_validate').show();
}

//display guess screen
function displayGuessScreen(){
  $('#registration').hide();
  $('#lobby').hide();
  $('#draw_panel').hide();
  $('#drawing_validate').hide();

  $('#guessing_validate').prop('disabled', false);
  $('#inputGuess').prop('disabled', false);
  $('#inputGuess').val('');

  $('#draw').show();
  $('#bottom_part_guess').show();
  $('#title').empty();
  $('#title').append('What is it ?');
}

// Send the drawing to server
function sendDessin(){
  socket.emit('draw_done', canvas[0].toDataURL());
}

//send guess to server
function sendGuess(){
  socket.emit('guess_done', $('#inputGuess').val());
}

// Get the position
function findXY(event, e) {
  if (event == "down") {
    flag = true;
    prevX = currX;
    prevY = currY;
    currX = e.clientX - canvas[0].offsetLeft + canvas[0].width/2;
    currY = e.clientY - canvas[0].offsetTop;
  } else if ((event == "up")||(event == "out")) {
    flag = false;
  } else if ((event == "move") && flag) {
    prevX = currX;
    prevY = currY;
    currX = e.clientX - canvas[0].offsetLeft + canvas[0].width/2;
    currY = e.clientY - canvas[0].offsetTop;
    draw();
  }
}

// Draw
function draw() {
  ctx.beginPath();
  ctx.moveTo(prevX, prevY);
  ctx.lineTo(currX, currY);
  ctx.stroke();
  ctx.closePath();
}
