var express = require('express'),
  app = express(),
  path = require('path'),
  server = require('http').createServer(app),
  io = require('socket.io').listen(server),
  uniqid = require('uniqid'),
  ent = require('ent');

var games = {};

// Set public directory
app.use('/public', express.static(path.join(__dirname, 'public')));

// Game Page
app.get('/:gameId', function(req, res) {
  res.sendFile(__dirname + '/draw.html');
});

io.sockets.on('connection', function(socket) {

  //New player
  socket.on('new_player', function(o){
    socket.gameId = o.gameId;

    if(games[o.gameId]) {
      // game allready started
      if(games[o.gameId].status == 'play'){
        socket.emit('message', 'Game allready started');
        return;
      }
    } else {
      games[o.gameId] = {status: 'lobby', players: [], sockets: [], turn: 0, topics: [], draw:[]};
    }
    games[o.gameId].players.push({pseudo: o.pseudo, ready: false, id: socket.id, action: 'LOBBY', who: -1});
    games[o.gameId].sockets.push(socket);
    games[o.gameId].topics.push([]);
    games[o.gameId].topics[games[o.gameId].topics.length-1].push(o.topic);
    games[o.gameId].draw.push([]);
    socket.emit('lobby');

    for(var i = 0; i < games[o.gameId].sockets.length; i++) {
      games[o.gameId].sockets[i].emit('players_list', games[socket.gameId].players);
    }
  });

  //Player ready/not ready
  socket.on('player_ready', function(r){

    //Set player ready
    if(games[socket.gameId]){
      playerReady(games[socket.gameId].players, socket.id, r);
    }

    //Send players
    sendToAllPlayers(games[socket.gameId].sockets, 'players_list', games[socket.gameId].players);

    //Check if all players is ready
    if(allPlayersReady(games[socket.gameId].players)){
      games[socket.gameId].status = 'play';
      sendToAllPlayers(games[socket.gameId].sockets, 'start', '');
      play(games[socket.gameId]);
    }
  });

  //draw done
  socket.on('draw_done', function(data) {
    //Set player ready
    var player = socket2Player(games[socket.gameId].players, socket.id);
    player.ready = true;
    games[socket.gameId].draw[player.who].push(data);

    //check if all players Ready
    if(allPlayersReady(games[socket.gameId].players)){
      play(games[socket.gameId]);
    }
  })

  //guess done
  socket.on('guess_done', function(data) {
    //Set player ready
    var player = socket2Player(games[socket.gameId].players, socket.id);
    player.ready = true;
    games[socket.gameId].topics[player.who].push(data);

    //check if all players Ready
    if(allPlayersReady(games[socket.gameId].players)){
      play(games[socket.gameId]);
    }
  });

});

//play
function play(game){
  if(game.turn <= 2*(game.players.length-1)){
    nextTurn(game);
    sendTurn(game);
  }
}

//Play next turn
function nextTurn(game) {
  game.turn++;
  var p = whoTurn(game.players.length, game.turn);
  for (var i = 0; i < game.sockets.length; i++) {
    game.players[i].ready = false;
    game.players[i].action = (game.turn%2==0) ? 'GUESS' : 'DRAW';
    game.players[i].who = (p+i)%game.players.length;
  }
}

//Send next turn
function sendTurn(game){
  for(var i = 0; i < game.sockets.length; i++){
    var who = game.players[i].who;
    if(game.turn%2==0){
      game.sockets[i].emit('guess', game.draw[who][game.draw[who].length-1]);
    } else {
      game.sockets[i].emit('draw', game.topics[who][game.topics[who].length-1]);
    }
  }
}

//Get turn order
function whoTurn(nbp, turn) {
  if (nbp%2 == 0){
    return (turn<=nbp-1) ? turn : turn-nbp+1;
  } else {
    if(turn<=nbp-1){
      return turn;
    } else {
      return ((turn-nbp)%2==0) ? turn-nbp+2 : turn-nbp;
    }
  }
}

//get player form socket id
function socket2Player(players, socketId){
  for(var i = 0; i < players.length; i++){
    if(players[i].id == socketId){
      return players[i];
    }
  }
  return undefined;
}

//Set player ready
function playerReady(players, socketId, isReady){
  var p = socket2Player(players, socketId);
  if(p){
    p.ready = isReady;
  }
}

//Send to all players of the game
function sendToAllPlayers(sockets, type, data){
  for(var i = 0; i < sockets.length; i++){
    sockets[i].emit(type, data);
  }
}

//Check is all players is ready
function allPlayersReady(players) {

  for(var i = 0; i < players.length; i++){
    if(!players[i].ready){
      return false;
    }
  }
  return true;
}




server.listen(8080);
